/*browser:true*/
/*global define*/
define([
  'Magento_Checkout/js/view/payment/default',
  'Magento_Checkout/js/action/place-order',
  'Magento_Checkout/js/model/quote',
  'Magento_Checkout/js/model/payment/additional-validators'
], function (
  Component,
  placeOrderAction,
  quote,
  additionalValidators
) {
  'use strict';

  return Component.extend({
    defaults: {
      template: 'Upc_EcommConnect/payment/form',
    },

    getCode: function () {
      return 'upc_ecommconnect';
    },

    getLogoUrl: function () {
      return window.checkoutConfig.payment.upc_ecommconnect.logoUrl;
    },

    getData: function () {
      return {
        method: this.getCode(),
        additional_data: {}
      };
    },

    placeOrder: function (data, event) {
      if (event) event.preventDefault();

      const self = this;

      const isValid =
        (typeof this.validate === 'function' ? this.validate() : true) &&
        additionalValidators.validate();

      if (!isValid) return false;

      this.isPlaceOrderActionAllowed(false);

      placeOrderAction(this.getData(), this.messageContainer).done(function (order) {
        const orderId = order;
        const billing = quote.billingAddress();
        const purchaseTime = self.getCurrentTime();
        const amount = Math.round(quote.totals().grand_total * 100);

        fetch('/rest/default/V1/upc/signature', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            order_id: orderId,
            total_amount: amount,
            purchase_time: purchaseTime
          })
        })
          .then(res => res.json())
          .then(data => {
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = data.action;
            const fields = {
              MerchantID: data.merchant_id,
              TerminalID: data.terminal_id,
              Signature: data.signature,
              Currency: data.currency,
              AltCurrency: data.alt_currency,
              AltTotalAmount: data.alt_total_amount,
              PurchaseDesc: 'Order #' + orderId,
              locale: data.locale,
              OrderID: orderId,
              PurchaseTime: purchaseTime,
              TotalAmount: amount,
              session: data.session,
              Delay: data.delay,
              email: (quote.guestEmail || (quote.billingAddress() && quote.billingAddress().email)) || '',
              phoneNumber: billing.telephone,
              consumerFirstName: billing.firstname,
              consumerLastName: billing.lastname
            };

            if (data.u_p_c_tocken && data.u_p_c_tocken.trim() !== '') {
              fields['UPCToken'] = data.u_p_c_tocken;
            }

            for (const key in fields) {
              const input = document.createElement('input');
              input.type = 'hidden';
              input.name = key;
              input.value = fields[key];
              form.appendChild(input);
            }

            document.body.appendChild(form);
            //console.log(form.outerHTML);
            form.submit();
          })
          .catch((error) => {
            self.isPlaceOrderActionAllowed(true);

            if (typeof error.text === 'function') {
              error.text().then(function (text) {
                self.messageContainer.addErrorMessage({
                  message: text || 'This currency is not supported for payment. Please contact support or change currency.'
                });
              });
            } else {
              self.messageContainer.addErrorMessage({
                message: 'This currency is not supported for payment. Please contact support or change currency.'
              });
            }
          });
      }).fail(function () {
        self.isPlaceOrderActionAllowed(true);
      });

      return true;
    },

    getCurrentTime: function () {
      const d = new Date();
      const pad = n => n.toString().padStart(2, '0');
      return (
        d.getFullYear().toString().slice(2) +
        pad(d.getMonth() + 1) +
        pad(d.getDate()) +
        pad(d.getHours()) +
        pad(d.getMinutes()) +
        pad(d.getSeconds())
      );
    }
  });
});
