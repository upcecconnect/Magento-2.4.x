<?php
namespace Upc\EcommConnect\Model\Config\Backend;

use Magento\Framework\App\Config\Value;
use Magento\Framework\Exception\LocalizedException;

class SecureTextareaBackend extends Value
{
    public function beforeSave()
    {
        $value = $this->getValue();
        $oldValue = $this->getOldValue();

        $fieldId = $this->getData('path');

        $requiredFields = [
            'payment/upc_ecommconnect/private_key',
            'payment/upc_ecommconnect/cert',
        ];

        $fieldNames = [
            'payment/upc_ecommconnect/private_key' => __('Private Key (Live)'),
            'payment/upc_ecommconnect/cert' => __('Certificate (Live)'),
        ];

        $name = $fieldNames[$fieldId] ?? $fieldId;

        if ($value === '') {
            $this->setValue($oldValue);

            if ($oldValue === '' && in_array($fieldId, $requiredFields)) {
                throw new LocalizedException(
                    __("The field '%1' is required and cannot be empty.", $name)
                );
            }
        }

        return parent::beforeSave();
    }
}
