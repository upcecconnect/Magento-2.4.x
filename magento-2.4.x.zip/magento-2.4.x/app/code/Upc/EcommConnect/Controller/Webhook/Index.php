<?php
namespace Upc\EcommConnect\Controller\Webhook;

use Exception;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\Request\InvalidRequestException;
use Magento\Framework\App\CsrfAwareActionInterface;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Encryption\EncryptorInterface;
use Magento\Framework\Exception\AlreadyExistsException;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Model\OrderRepository;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Psr\Log\LoggerInterface;
use Upc\EcommConnect\Service\SignatureVerifier;
use Magento\Sales\Model\Order;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Model\ResourceModel\Customer as CustomerResource;

class Index extends Action implements CsrfAwareActionInterface
{
    private const string ORDER_ID = 'OrderID';
    private const string MERCHANT_ID = 'MerchantID';
    private const string TERMINAL_ID = 'TerminalID';
    private const string PURCHASE_TIME = 'PurchaseTime';
    private const string XID = 'XID';
    private const string CURRENCY = 'Currency';
    private const string ALT_CURRENCY = 'AltCurrency';
    private const string TOTAL_AMOUNT = 'TotalAmount';
    private const string ALT_TOTAL_AMOUNT = 'AltTotalAmount';
    private const string SD = 'SD';
    private const string TRAN_CODE = 'TranCode';
    private const string APPROVAL_CODE = 'ApprovalCode';
    private const string SIGNATURE = 'Signature';
    private const string DELAY = 'Delay';
    private const string UPC_TOKEN_EXP = 'UPCTokenExp';
    private const string UPC_TOKEN = 'UPCToken';
    private const string RRN = 'Rrn';

    protected ScopeConfigInterface $scopeConfig;
    protected LoggerInterface $logger;
    protected RequestInterface $request;
    protected SignatureVerifier $signatureVerifier;
    protected OrderRepository $orderRepository;
    protected StoreManagerInterface $storeManager;
    protected EncryptorInterface $encryptor;
    protected CustomerRepositoryInterface $customerRepository;
    protected CustomerResource $customerResource;
    private bool $isTestMode = false;


    public function __construct(
        Context $context,
        LoggerInterface $logger,
        RequestInterface $request,
        ScopeConfigInterface $scopeConfig,
        SignatureVerifier $signatureVerifier,
        StoreManagerInterface $storeManager,
        OrderRepository $orderRepository,
        EncryptorInterface $encryptor,
        CustomerRepositoryInterface $customerRepository,
        CustomerResource $customerResource,
    ) {
        parent::__construct($context);
        $this->logger = $logger;
        $this->request = $request;
        $this->scopeConfig = $scopeConfig;
        $this->signatureVerifier = $signatureVerifier;
        $this->orderRepository = $orderRepository;
        $this->storeManager = $storeManager;
        $this->encryptor = $encryptor;
        $this->customerRepository = $customerRepository;
        $this->customerResource = $customerResource;
        $this->isTestMode = $this->scopeConfig->isSetFlag('payment/upc_ecommconnect/test_mode');
    }

    public function createCsrfValidationException(RequestInterface $request): ?InvalidRequestException
    {
        return null;
    }

    public function validateForCsrf(RequestInterface $request): ?bool
    {
        return true;
    }

    public function execute(): void
    {
        $raw = $this->request->getContent();
        parse_str($raw, $params);

        $response = '';
        $forwardUrl = $this->storeManager->getStore()->getUrl('checkout/onepage/success');
        $failureUrl = $this->storeManager->getStore()->getUrl('ecommconnect/payment/failure');

        if ($this->isTestMode) {
            $this->logger->info('Webhook RAW Body: ' . $raw);
            $this->logger->info('Webhook Parsed Params:', $params);
        }

        $orderId = $params[self::ORDER_ID] ?? null;
        $tranCode = $params[self::TRAN_CODE] ?? null;
        $upcToken = $params[self::UPC_TOKEN] ?? null;
        $upcTokenExp = $params[self::UPC_TOKEN_EXP] ?? null;

        if (!$orderId || !$tranCode) {
            $missingParams = [];
            if (!$orderId) {
                $missingParams[] = self::ORDER_ID;
            }
            if (!$tranCode) {
                $missingParams[] = self::TRAN_CODE;
            }

            $response = "Response.action=reverse\n";
            $response .= "Response.reason=Missing required parameters: " . implode(', ', $missingParams) . "\n";
            $response .= "Response.forwardUrl={$failureUrl}\n";

            $this->getResponse()
                ->setHeader('Content-Type', 'text/plain', true)
                ->setBody($response);

            return;
        }

        $signature = $params[self::SIGNATURE] ?? '';

        $data = sprintf(
            '%s;%s;%s;%s,%s;%s;%s,%s;%s,%s;%s;%s;%s;%s%s',
            $params[self::MERCHANT_ID] ?? '',
            $params[self::TERMINAL_ID] ?? '',
            $params[self::PURCHASE_TIME] ?? '',
            $orderId,
            $params[self::DELAY],
            $params[self::XID] ?? '',
            $params[self::CURRENCY] ?? '',
            $params[self::ALT_CURRENCY] ?? '',
            $params[self::TOTAL_AMOUNT] ?? '',
            $params[self::ALT_TOTAL_AMOUNT] ?? '',
            $params[self::SD] ?? '',
            $tranCode,
            $params[self::APPROVAL_CODE] ?? '',
            $upcToken ?? '',
            $upcTokenExp ? ','.$upcTokenExp.';' : ''
        );

        $verified = $this->isTestMode || $this->signatureVerifier->verify($data, $signature);

        if ($verified && $tranCode === '000') {
            try {
                $order = $this->orderRepository->get($orderId);

                if ($order->getId() && $order->getState() !== Order::STATE_PROCESSING) {

                    if($upcToken && $upcTokenExp){
                        $this->setUPCToken($order, $upcToken, $upcTokenExp);
                    }

                    $forwardUrl = $this->generateSecuredReturnUrl(
                        $order,
                        $this->storeManager,
                        $this->encryptor,
                        $this->scopeConfig
                    );

                    if ($this->isTestMode) {
                        $this->logger->info('$forwardUrl: ' . $forwardUrl);
                    }

                    if (((bool)$params[self::DELAY])) {
                        $order->setState(Order::STATE_PROCESSING)
                              ->setStatus('awaiting_capture');

                        $order->addCommentToStatusHistory(
                            __('Оплата ініційована як Pre-Authorization через UPC. Очікуємо підтвердження.'),
                            false,
                            false
                        );
                        $payment = $order->getPayment();

                        $rrn = $params[self::RRN] ?? null;

                        $payment->setAdditionalInformation('upc_approval_code', $params[self::APPROVAL_CODE]);
                        $payment->setAdditionalInformation('upc_rrn', $rrn);
                        $payment->setAdditionalInformation('upc_purchase_time', $params[self::PURCHASE_TIME]);
                        $payment->setAdditionalInformation('upc_signature', $params[self::SIGNATURE]);

                    }else {
                        $order->setState(Order::STATE_PROCESSING)
                              ->setStatus(Order::STATE_PROCESSING);

                        $order->addCommentToStatusHistory(
                            __('Оплата успішна. Статус оновлено через UPC Webhook.'),
                            Order::STATE_PROCESSING,
                            false
                        );
                    }

                    $this->orderRepository->save($order);
                }

                $response = "Response.action=approve\n";
                $response .= "Response.reason=Order updated successfully for OrderID: {$orderId}\n";
                $response .= "Response.forwardUrl={$forwardUrl}\n";
            } catch (Exception $e) {
                $this->logger->error('Webhook Order Update Error: ' . $e->getMessage());

                $response = "Response.action=reverse\n";
                $response .= "Response.reason=Order processing error: {$e->getMessage()}\n";
                $response .= "Response.forwardUrl={$failureUrl}\n";

                $this->getResponse()
                    ->setHeader('Content-Type', 'text/plain', true)
                    ->setBody($response);

                return;
            }
        } else {
            if (!$verified) {
                $response = "Response.action=reverse\n";
                $response .= "Response.reason=Signature verification failed. Provided signature: {$signature}\n";
                $response .= "Response.forwardUrl={$failureUrl}\n";
            } elseif ($tranCode !== '000') {
                $response = "Response.action=reverse\n";
                $response .= "Response.reason=Invalid transaction code: {$tranCode}. Expected: 000\n";
                $response .= "Response.forwardUrl={$failureUrl}\n";
            }
        }

        $this->getResponse()
            ->setHeader('Content-Type', 'text/plain', true)
            ->setBody($response);
    }

    private function generateSecuredReturnUrl(
        OrderInterface $order,
        StoreManagerInterface $storeManager,
        EncryptorInterface $encryptor,
        ScopeConfigInterface $scopeConfig
    ): string {
        $orderIncrementId = $order->getIncrementId();
        $customerEmail = $order->getCustomerEmail();

        $secretKey = $scopeConfig->getValue('web/secure/base_url', ScopeInterface::SCOPE_STORE);
        $hashedEmail = hash_hmac('sha256', $customerEmail, $secretKey);
        $encodedParam = base64_encode($orderIncrementId . '|' . $hashedEmail);

        return $storeManager->getStore()->getUrl(
            'ecommconnect/payment/success',
            [
                '_query' => ['id' => $encodedParam],
                '_secure' => true
            ]
        );
    }

    /**
     * @throws NoSuchEntityException
     * @throws AlreadyExistsException
     * @throws LocalizedException
     * @throws InputException
     * @throws Exception
     */
    private function setUPCToken(OrderInterface $order, string $token, string $tokenExp): void
    {

        if ($order->getCustomerIsGuest()) {
            $this->logger->info("Guest checkout, no token save");
            return;
        }

        $customerId = $order->getCustomerId();
        if ($customerId && $token && $tokenExp) {

            $expMonth = (int)substr($tokenExp, 0, 2);
            $expYear = (int)substr($tokenExp, 2, 4);

            $currentMonth = (int)date('m');
            $currentYear = (int)date('Y');

            $isValid = ($expYear > $currentYear) || ($expYear === $currentYear && $expMonth >= $currentMonth);

            if ($isValid) {
                $customer = $this->customerRepository->getById($customerId);

                $customer->setCustomAttribute('upc_token', $token);
                $customer->setCustomAttribute('upc_token_exp', $tokenExp);

                if($this->isTestMode){
                    $this->logger->info("UPC Token: {$token} , Exp: {$tokenExp}");
                }

                $this->customerRepository->save($customer);
            }
        }
    }
}