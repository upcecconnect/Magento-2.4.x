<?php
namespace Upc\EcommConnect\Block\Adminhtml\System\Config;

use Magento\Config\Block\System\Config\Form\Field;
use Magento\Framework\Data\Form\Element\AbstractElement;

class SecureTextareaField extends Field
{
    protected function _getElementHtml(AbstractElement $element)
    {
        $element->setValue('');

        $html = '<div class="message message-success success">'
                . '<div>' . __('Value is already saved. Enter a new value to update.') . '</div>'
                . '</div>';
        $html .= parent::_getElementHtml($element);

        return $html;
    }
}
