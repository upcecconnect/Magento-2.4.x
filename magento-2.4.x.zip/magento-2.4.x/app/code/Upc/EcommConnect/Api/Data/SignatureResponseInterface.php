<?php
namespace Upc\EcommConnect\Api\Data;

/**
 *
 */
interface SignatureResponseInterface
{
    /**
     * @return string
     */
    public function getAction(): string;

    /**
     * @return string
     */
    public function getMerchantId(): string;

    /**
     * @return string
     */
    public function getTerminalId(): string;

    /**
     * @return string
     */
    public function getSignature(): string;

    /**
     * @return string
     */
    public function getCurrency(): string;

    /**
     * @return int
     */
    public function getDelay(): int;

    /**
     * @return string
     */
    public function getUPCTocken(): string;

    /**
     * @return string
     */
    public function getSession(): string;

    /**
     * @return string
     */
    public function getAltCurrency(): string;

    /**
     * @return int
     */
    public function getAltTotalAmount(): int;

    /**
     * @return string
     */
    public function getLocale(): string;

    /**
     * @param string $value
     *
     * @return self
     */
    public function setAction(string $value): self;

    /**
     * @param string $value
     *
     * @return self
     */
    public function setMerchantId(string $value): self;

    /**
     * @param string $value
     *
     * @return self
     */
    public function setTerminalId(string $value): self;

    /**
     * @param string $value
     *
     * @return self
     */
    public function setSignature(string $value): self;

    /**
     * @param string $value
     *
     * @return self
     */
    public function setCurrency(string $value): self;

    /**
     * @param string $value
     *
     * @return self
     */
    public function setSession(string $value): self;

    /**
     * @param int $value
     *
     * @return self
     */
    public function setDelay(int $value): self;

    /**
     * @param string $value
     *
     * @return self
     */
    public function setUpcToken(string $value): self;

    /**
     * @param string $value
     *
     * @return self
     */
    public function setAltCurrency(string $value): self;

    /**
     * @param int $value
     *
     * @return self
     */
    public function setAltTotalAmount(int $value): self;

    /**
     * @param string $value
     *
     * @return self
     */
    public function setLocale(string $value): self;
}
