<?php

declare(strict_types=1);

namespace Upc\EcommConnect\Service;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Store\Model\ScopeInterface;
use Psr\Log\LoggerInterface;

class SignatureGenerator
{
    private ScopeConfigInterface $scopeConfig;

    private LoggerInterface $logger;

    public function __construct(
        ScopeConfigInterface $scopeConfig,
        LoggerInterface $logger
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->logger = $logger;
    }

    /**
     * @param array $params [merchantId, terminalId, timestamp, orderId, currency, amount, delay]
     *
     * @return string base64-encoded signature
     * @throws LocalizedException
     */
    public function generate(array $params): string
    {
        if (count($params) !== 9) {
            throw new LocalizedException(__('Invalid data for signature generation.'));
        }

        $data = sprintf(
            '%s;%s;%s;%s,%s;%s,%s;%s,%s;',
            $params[0], // MerchantID
            $params[1], // TerminalID
            $params[2], // PurchaseTime
            $params[3], // OrderID
            $params[6], // Delay ("1" || "0")
            $params[4], // Currency
            $params[7], //AltCurrency
            $params[5], // TotalAmount
            $params[8]  // AltTotalAmount
        );

        $data .= ';';

        $isTestMode = $this->scopeConfig->isSetFlag(
            'payment/upc_ecommconnect/test_mode',
            ScopeInterface::SCOPE_STORE
        );

        $configPath = $isTestMode
            ? 'payment/upc_ecommconnect/private_key_test'
            : 'payment/upc_ecommconnect/private_key';

        $privateKey = $this->scopeConfig->getValue($configPath, ScopeInterface::SCOPE_STORE);

        if (empty($privateKey)) {
            throw new LocalizedException(__('PEM key file not found: %1', $configPath));
        }

        try {
            $pkeyId = openssl_pkey_get_private($privateKey);

            if (!$pkeyId) {
                throw new \RuntimeException('Invalid private key format.');
            }

            $signature = '';
            $success = openssl_sign($data, $signature, $pkeyId, OPENSSL_ALGO_SHA512);

            if (!$success) {
                throw new \RuntimeException('Failed to sign data.');
            }

            return base64_encode($signature);
        } catch (\Throwable $e) {
            $this->logger->error('Signature generation error: ' . $e->getMessage());
            throw new LocalizedException(__('Unable to generate digital signature.'));
        }
    }
}