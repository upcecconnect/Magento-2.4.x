<?php

namespace Upc\EcommConnect\Setup;

use Exception;
use Magento\Customer\Model\Customer;
use Magento\Customer\Setup\CustomerSetup;
use Magento\Customer\Setup\CustomerSetupFactory;
use Magento\Eav\Model\Config;
use Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface;
use Magento\Framework\Exception\AlreadyExistsException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Validator\ValidateException;
use Magento\Sales\Model\Order\StatusFactory;
use Magento\Sales\Model\ResourceModel\Order\Status as StatusResource;

class InstallData implements InstallDataInterface
{
    private CustomerSetupFactory $customerSetupFactory;
    private Config $eavConfig;
    private StatusFactory $statusFactory;
    private StatusResource $statusResource;

    public function __construct(
        CustomerSetupFactory $customerSetupFactory,
        Config $eavConfig,
        StatusFactory $statusFactory,
        StatusResource $statusResource
    ) {
        $this->customerSetupFactory = $customerSetupFactory;
        $this->eavConfig = $eavConfig;
        $this->statusFactory = $statusFactory;
        $this->statusResource = $statusResource;
    }

    /**
     * @throws ValidateException
     * @throws LocalizedException
     * @throws Exception
     */
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        /** @var CustomerSetup $customerSetup */
        $customerSetup = $this->customerSetupFactory->create(['setup' => $setup]);
        $customerEntity = $customerSetup->getEntityTypeId(Customer::ENTITY);
        $attributeSetId = $customerSetup->getDefaultAttributeSetId($customerEntity);
        $attributeGroup = 'General';

        $customerSetup->addAttribute(Customer::ENTITY, 'upc_token', [
            'type' => 'varchar',
            'label' => 'UPC Token',
            'input' => 'text',
            'required' => false,
            'visible' => true,
            'user_defined' => true,
            'system' => 0,
            'global' => ScopedAttributeInterface::SCOPE_GLOBAL,
            'visible_on_front' => false,
            'sort_order' => 1000
        ]);

        $customerSetup->addAttributeToSet(
            $customerEntity,
            $attributeSetId,
            $attributeGroup,
            'upc_token'
        );

        $attribute = $this->eavConfig->getAttribute(Customer::ENTITY, 'upc_token');
        $attribute->setData('used_in_forms', [
            'adminhtml_customer',
            'customer_account_edit',
            'customer_register_account'
        ]);
        $attribute->setData('is_user_defined', true);
        $attribute->setData('is_visible', true);

        /**
         * @noinspection PhpDeprecationInspection
         */
        $attribute->save();

        $customerSetup->addAttribute(Customer::ENTITY, 'upc_token_exp', [
            'type' => 'varchar',
            'label' => 'UPC Token Expiration',
            'input' => 'text',
            'required' => false,
            'visible' => true,
            'user_defined' => true,
            'system' => 0,
            'global' => ScopedAttributeInterface::SCOPE_GLOBAL,
            'visible_on_front' => false,
            'sort_order' => 1000
        ]);

        $customerSetup->addAttributeToSet(
            $customerEntity,
            $attributeSetId,
            $attributeGroup,
            'upc_token_exp'
        );

        $attribute = $this->eavConfig->getAttribute(Customer::ENTITY, 'upc_token_exp');
        $attribute->setData('used_in_forms', [
            'adminhtml_customer',
            'customer_account_edit',
            'customer_register_account'
        ]);
        $attribute->setData('is_user_defined', true);
        $attribute->setData('is_visible', true);

        /** Створюємо статус замовлення */
        $status = $this->statusFactory->create();
        $status->setData(['status' => 'awaiting_capture', 'label' => 'Awaiting Capture']);

        try {
            $this->statusResource->save($status);
            $this->statusResource->assignState('awaiting_capture', 'processing', false);
        } catch (AlreadyExistsException $e) {
            // Якщо вже є, ігноруємо
        }
    }
}