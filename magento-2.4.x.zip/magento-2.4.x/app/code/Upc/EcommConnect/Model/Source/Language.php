<?php

declare(strict_types=1);

namespace Upc\EcommConnect\Model\Source;

class Language
{
    public function toOptionArray(): array
    {
        return [
            ['value' => 'en', 'label' => 'English (default)'],
            ['value' => 'uk', 'label' => 'Ukrainian (UAH)'],
            ['value' => 'sr', 'label' => 'Serbian (RSD)'],
            ['value' => 'hu', 'label' => 'Hungarian (HUF)'],
            ['value' => 'bg', 'label' => 'Bulgarian (BGN)'],
            ['value' => 'sq', 'label' => 'Albanian (ALL)'],
            ['value' => 'bs', 'label' => 'Bosnian (BAM)'],
            ['value' => 'de', 'label' => 'German (EUR)'],
        ];
    }
}
