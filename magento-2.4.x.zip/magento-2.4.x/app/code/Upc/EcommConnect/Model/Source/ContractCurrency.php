<?php

declare(strict_types=1);

namespace Upc\EcommConnect\Model\Source;

class ContractCurrency
{
    public function toOptionArray(): array
    {
        return [
            ['value' => '840', 'label' => 'USD'],
            ['value' => '978', 'label' => 'EUR'],
            ['value' => '980', 'label' => 'UAH'],
            ['value' => '977', 'label' => 'BAM'],
            ['value' => '348', 'label' => 'HUF'],
            ['value' => '975', 'label' => 'BGN'],
            ['value' => '941', 'label' => 'RSD'],
            ['value' => '008', 'label' => 'ALL'],
        ];
    }
}