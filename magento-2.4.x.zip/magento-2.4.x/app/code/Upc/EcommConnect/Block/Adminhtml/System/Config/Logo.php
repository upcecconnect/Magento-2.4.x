<?php
namespace Upc\EcommConnect\Block\Adminhtml\System\Config;

use Magento\Config\Block\System\Config\Form\Field;
use Magento\Framework\Data\Form\Element\AbstractElement;

class Logo extends Field
{
    /**
     * Повертаємо HTML для рендеру поля
     *
     * @param AbstractElement $element
     * @return string
     */
    protected function _getElementHtml(AbstractElement $element): string
    {
        $url = $this->getViewFileUrl('Upc_EcommConnect::images/logo.svg');
        return '<div style="margin:10px 0;">
                    <img src="'.$url.'" alt="UPC Payment" style="max-height:40px;" />
                </div>';
    }
}
