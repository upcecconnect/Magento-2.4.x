<?php
namespace Upc\EcommConnect\Model\Data;

use Upc\EcommConnect\Api\Data\SignatureResponseInterface;
use Magento\Framework\DataObject;

class SignatureResponse extends DataObject implements SignatureResponseInterface
{
    public function getAction(): string
    {
        return (string)$this->getData('action');
    }

    public function getMerchantId(): string
    {
        return (string)$this->getData('merchant_id');
    }

    public function getTerminalId(): string
    {
        return (string)$this->getData('terminal_id');
    }

    public function getSignature(): string
    {
        return (string)$this->getData('signature');
    }

    public function getCurrency(): string
    {
        return (string)$this->getData('currency');
    }

    public function getSession(): string
    {
        return (string)$this->getData('session');
    }

    public function getDelay(): int
    {
        return $this->getData('delay');
    }

    public function getUPCTocken(): string
    {
        return (string)$this->getData('upc_token');
    }

    public function setAction(string $value): SignatureResponseInterface
    {
        return $this->setData('action', $value);
    }

    public function setMerchantId(string $value): SignatureResponseInterface
    {
        return $this->setData('merchant_id', $value);
    }

    public function setTerminalId(string $value): SignatureResponseInterface
    {
        return $this->setData('terminal_id', $value);
    }

    public function setSignature(string $value): SignatureResponseInterface
    {
        return $this->setData('signature', $value);
    }

    public function setCurrency(string $value): SignatureResponseInterface
    {
        return $this->setData('currency', $value);
    }

    public function setSession(string $value): SignatureResponseInterface
    {
        return $this->setData('session', $value);
    }

    public function setDelay(int $value): SignatureResponseInterface
    {
       return $this->setData('delay', $value);
    }

    public function setUpcToken(string $value): SignatureResponseInterface
    {
        return $this->setData('upc_token', $value);
    }

    public function getAltCurrency(): string
    {
        return (string)$this->getData('alt_currency');
    }

    public function getAltTotalAmount(): int
    {
        return (string)$this->getData('alt_total_amount');
    }

    public function setAltCurrency(string $value): SignatureResponseInterface
    {
        return $this->setData('alt_currency', $value);
    }

    public function setAltTotalAmount(int $value): SignatureResponseInterface
    {
        return $this->setData('alt_total_amount', $value);
    }

    public function getLocale(): string
    {
        return (string)$this->getData('locale');
    }

    public function setLocale(string $value): SignatureResponseInterface
    {
       return $this->setData('locale', $value);
    }
}