<?php

namespace Upc\EcommConnect\Block\Adminhtml\Order\View;

use Magento\Backend\Block\Template;
use Magento\Backend\Block\Template\Context;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Upc\EcommConnect\Service\CurrencyCodeResolver;

class CaptureButton extends Template
{
    protected $_template = 'Upc_EcommConnect::order/capture.phtml';
    protected OrderRepositoryInterface $orderRepository;
    protected ScopeConfigInterface $scopeConfig;
    protected CurrencyCodeResolver $currencyResolver;

    public function __construct(
        Context $context,
        OrderRepositoryInterface $orderRepository,
        ScopeConfigInterface $scopeConfig,
        CurrencyCodeResolver $currencyResolver,
        array $data = []
    ) {
        $this->orderRepository = $orderRepository;
        $this->scopeConfig = $scopeConfig;
        $this->currencyResolver = $currencyResolver;

        parent::__construct($context, $data);
    }

    public function canShow(): bool
    {
        $order = $this->getOrder();

        return $order->getStatus() === 'awaiting_capture';
    }

    public function getOrder(): OrderInterface
    {
        $orderId = $this->getRequest()->getParam('order_id');

        return $this->orderRepository->get($orderId);
    }

    public function getCaptureFormData(OrderInterface $order): array
    {
        $payment = $order->getPayment();

        return [
            'merchant_id' => $this->scopeConfig->getValue('payment/upc_ecommconnect/merchant_id'),
            'terminal_id' => $this->scopeConfig->getValue('payment/upc_ecommconnect/terminal_id'),
            'currency'    => $this->currencyResolver->getNumericCode(),
            'purchase_time' => $payment->getAdditionalInformation('upc_purchase_time'),
            'approval_code' => $payment->getAdditionalInformation('upc_approval_code'),
            'rrn'           => $payment->getAdditionalInformation('upc_rrn'),
            'signature'     => $payment->getAdditionalInformation('upc_signature'),
        ];
    }
}

