/*browser:true*/
/*global define*/
define(
    [
        'uiComponent',
        'Magento_Checkout/js/model/payment/renderer-list'
    ],
    function (
        Component,
        rendererList
    ) {
        'use strict';
        rendererList.push(
            {
                type: 'upc_ecommconnect',
                component: 'Upc_EcommConnect/js/view/payment/method-renderer/upc_ecommconnect'
            }
        );
        /** Add view logic here if needed */
        return Component.extend({});
    }
);
