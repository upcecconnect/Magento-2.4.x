<?php

namespace Upc\EcommConnect\Controller\Payment;

use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\App\Request\InvalidRequestException;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Encryption\EncryptorInterface;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Sales\Model\Order;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Sales\Model\Order\Status\HistoryFactory;
use Magento\Store\Model\ScopeInterface;
use Psr\Log\LoggerInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\App\CsrfAwareActionInterface;

class Success extends Action implements CsrfAwareActionInterface
{
    /**
     * @var OrderRepositoryInterface
     */
    protected OrderRepositoryInterface $orderRepository;

    /**
     * @var CheckoutSession
     */
    protected CheckoutSession $checkoutSession;

    /**
     * @var HistoryFactory
     */
    protected HistoryFactory $orderHistoryFactory;

    /**
     * @var LoggerInterface
     */
    protected LoggerInterface $logger;

    protected EncryptorInterface $encryptor;
    protected ScopeConfigInterface $scopeConfig;
    protected SearchCriteriaBuilder $searchCriteriaBuilder;
    protected FilterBuilder $filterBuilder;

    public function __construct(
        Context $context,
        OrderRepositoryInterface $orderRepository,
        CheckoutSession $checkoutSession,
        HistoryFactory $orderHistoryFactory,
        LoggerInterface $logger,
        EncryptorInterface $encryptor,
        ScopeConfigInterface $scopeConfig,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        FilterBuilder $filterBuilder,
    ) {
        parent::__construct($context);
        $this->orderRepository = $orderRepository;
        $this->checkoutSession = $checkoutSession;
        $this->orderHistoryFactory = $orderHistoryFactory;
        $this->encryptor = $encryptor;
        $this->scopeConfig = $scopeConfig;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->filterBuilder = $filterBuilder;
        $this->logger = $logger;
    }

    public function createCsrfValidationException(RequestInterface $request): ?InvalidRequestException
    {
        return null;
    }

    public function validateForCsrf(RequestInterface $request): ?bool
    {
        return true;
    }

    public function execute()
    {
        $encodedParam = $this->getRequest()->getParam('id');
        $orderIncrementId = null;

        if (!$encodedParam) {
            $this->messageManager->addErrorMessage(__('Payment processing failed: Invalid link.'));

            return $this->resultRedirectFactory->create()->setPath('checkout/cart');
        }

        try {
            $decodedParam = base64_decode($encodedParam);

            $parts = explode('|', $decodedParam);
            if (count($parts) !== 2) {
                throw new \Exception('Invalid decoded parameters format.');
            }
            list($orderIncrementId, $receivedHashedEmail) = $parts;
            $secretKey = $this->scopeConfig->getValue('web/secure/base_url', ScopeInterface::SCOPE_STORE);

            $searchCriteriaBuilder = ObjectManager::getInstance()
                                                  ->get(SearchCriteriaBuilder::class);
            $filterBuilder = ObjectManager::getInstance()
                                          ->get(FilterBuilder::class);

            $filter = $filterBuilder
                ->setField('increment_id')
                ->setValue($orderIncrementId)
                ->create();

            $searchCriteria = $searchCriteriaBuilder->addFilters([$filter])->create();
            $orderList = $this->orderRepository->getList($searchCriteria)->getItems();

            if (count($orderList) === 0) {
                throw new NoSuchEntityException(__('Order with increment ID "%1" does not exist.', $orderIncrementId));
            }
            $order = current($orderList);

            $actualCustomerEmail = $order->getCustomerEmail();
            $expectedHashedEmail = hash_hmac('sha256', $actualCustomerEmail, $secretKey);

            if (!hash_equals($expectedHashedEmail, $receivedHashedEmail)) {
                throw new \Exception('Security check failed: Email hash mismatch.');
            }

            $customerSession = $this->_objectManager->get(Session::class);

            if (!$order->getCustomerIsGuest() && $order->getCustomerId()) {
                try {
                    $customer = $this->_objectManager->get(CustomerRepositoryInterface::class)
                                                     ->getById($order->getCustomerId());

                    $customerSession->setCustomerDataAsLoggedIn($customer);
                } catch (NoSuchEntityException $e) {
                    $this->logger->warning("Customer not found for order: " . $order->getIncrementId());
                }
            }

            $this->checkoutSession->setLastOrderId($order->getId());
            $this->checkoutSession->setLastRealOrderId($order->getIncrementId());
            $this->checkoutSession->setLastSuccessQuoteId($order->getQuoteId());
            $this->checkoutSession->setLastQuoteId($order->getQuoteId());
            $this->checkoutSession->setLastOrderStatus($order->getStatus());

            $resultRedirect = $this->resultRedirectFactory->create();

            return $resultRedirect->setPath('checkout/onepage/success');

        } catch (NoSuchEntityException $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
            $this->logger->error(sprintf("Failed to process payment return: %s", $e->getMessage()));
            return $this->resultRedirectFactory->create()->setPath('checkout/cart');
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage(__('An error occurred during payment processing. Please contact support.'));
            $this->logger->error(sprintf("Unexpected error in payment return: %s", $e->getMessage()));
            return $this->resultRedirectFactory->create()->setPath('checkout/cart');
        }
    }
}