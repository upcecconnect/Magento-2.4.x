<?php

namespace Upc\EcommConnect\Block\Adminhtml\System\Config\Field;

use Magento\Config\Block\System\Config\Form\Field;
use Magento\Framework\Data\Form\Element\AbstractElement;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Backend\Block\Template\Context;

class ContractCurrency extends Field
{
    protected StoreManagerInterface $storeManager;

    public function __construct(
        Context $context,
        StoreManagerInterface $storeManager,
        array $data = []
    ) {
        $this->storeManager = $storeManager;
        parent::__construct($context, $data);
    }

    public function render(AbstractElement $element): string
    {
        $baseCurrency = $this->storeManager->getStore()->getBaseCurrencyCode();

        $html = $element->getElementHtml();

        $commentHtml = sprintf(
            '<p class="note"><span>%s</span></p>',
            __('Select the currency agreed in your merchant contract. (Current store base currency: <strong style="color:green;">%1</strong>)', $baseCurrency)
        );

        return sprintf(
            '<tr id="row_%1$s"><td class="label"><label for="%1$s">%2$s</label></td><td class="value">%3$s%4$s</td></tr>',
            $element->getHtmlId(),
            $element->getLabel(),
            $html,
            $commentHtml
        );
    }
}