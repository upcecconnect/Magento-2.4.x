<?php

declare(strict_types=1);

namespace Upc\EcommConnect\Service;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\Exception\LocalizedException;
use Psr\Log\LoggerInterface;

class SignatureVerifier
{
    private ScopeConfigInterface $scopeConfig;

    private LoggerInterface $logger;

    public function __construct(
        ScopeConfigInterface $scopeConfig,
        LoggerInterface $logger
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->logger = $logger;
    }

    /**
     * Verify the given signature using the configured public certificate.
     *
     * @param string $data The original data that was signed.
     * @param string $signature The base64-encoded signature to verify.
     *
     * @return bool             True if the signature is valid, false otherwise.
     */
    public function verify(string $data, string $signature): bool
    {
        $isTestMode = $this->scopeConfig->isSetFlag(
            'payment/upc_ecommconnect/test_mode',
            ScopeInterface::SCOPE_STORE
        );

        $certPath = $isTestMode
            ? 'payment/upc_ecommconnect/cert_test'
            : 'payment/upc_ecommconnect/cert';

        $certificate = $this->scopeConfig->getValue($certPath, ScopeInterface::SCOPE_STORE);

        if (empty($certificate)) {
            $this->logger->error("Certificate is empty in config path: {$certPath}");

            return false;
        }

        try {
            $publicKey = openssl_pkey_get_public($certificate);

            if (!$publicKey) {
                $this->logger->error("Invalid certificate format in config path: {$certPath}");

                return false;
            }

            $decodedSignature = base64_decode($signature, true);

            if ($decodedSignature === false) {
                $this->logger->error("Failed to base64-decode the signature.");

                return false;
            }

            $result = openssl_verify($data, $decodedSignature, $publicKey, OPENSSL_ALGO_SHA512);

            return $result === 1;
        } catch (\Throwable $e) {
            $this->logger->error('Signature verification error: ' . $e->getMessage());

            return false;
        }
    }
}