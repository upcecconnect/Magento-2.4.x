<?php
namespace Upc\EcommConnect\Api;

use Upc\EcommConnect\Api\Data\SignatureResponseInterface;

interface SignatureInterface
{
    /**
     * @param string $order_id
     * @param int $total_amount
     * @param string $purchase_time
     *
     * @return SignatureResponseInterface
     */
    public function generateSignature(string $order_id, int $total_amount, string $purchase_time): SignatureResponseInterface;
}
