<?php
namespace Upc\EcommConnect\Gateway\Command;

use Magento\Payment\Gateway\CommandInterface;
use Magento\Sales\Model\Order;

class PreauthorizeCommand implements CommandInterface
{
    public function execute(array $commandSubject)
    {
        if (!isset($commandSubject['payment'])) {
            return null;
        }

        $payment = $commandSubject['payment']->getPayment();
        $order = $payment->getOrder();

        $payment->setIsTransactionPending(true);
        $payment->setIsTransactionClosed(false);

        $order->setState(Order::STATE_PAYMENT_REVIEW)
              ->setStatus(Order::STATE_PAYMENT_REVIEW);

        $order->addCommentToStatusHistory(
            __('Пре-авторизація платежу через UPC e-Commerce Gateway. Очікуємо підтвердження.'),
            false,
            false
        );

        return null;
    }
}