<?php
namespace Upc\EcommConnect\Model\Ui;

use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Framework\View\Asset\Repository;

/**
 * Class ConfigProvider
 */
final class ConfigProvider implements ConfigProviderInterface
{
    const string CODE = 'upc_ecommconnect';
    protected Repository $assetRepo;

    public function __construct(
        Repository $assetRepo
    ) {
        $this->assetRepo = $assetRepo;
    }


    /**
     * Retrieve an assoc array of checkout configuration
     *
     * @return array
     */
    public function getConfig(): array
    {
        return [
            'payment' => [
                self::CODE => [
                    'logoUrl' => $this->assetRepo->getUrl('Upc_EcommConnect::images/logo.svg')
                ]
            ]
        ];
    }
}
