<?php

namespace Upc\EcommConnect\Model;

use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Sales\Model\OrderRepository;
use Upc\EcommConnect\Api\SignatureInterface;
use Upc\EcommConnect\Service\PaymentCurrencyResolver;
use Upc\EcommConnect\Service\SignatureGenerator;
use Upc\EcommConnect\Service\CurrencyCodeResolver;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Upc\EcommConnect\Api\Data\SignatureResponseInterface;
use Upc\EcommConnect\Model\Data\SignatureResponse;
use Magento\Framework\ObjectManagerInterface;
use Magento\Customer\Model\Session as CustomerSession;

class Signature implements SignatureInterface
{
    /**
     * @param ScopeConfigInterface $scopeConfig
     * @param SignatureGenerator $signatureGenerator
     * @param CurrencyCodeResolver $currencyResolver
     * @param ObjectManagerInterface $objectManager
     * @param CustomerSession $customerSession
     * @param CustomerRepositoryInterface $customerRepository
     * @param OrderRepository $orderRepository
     * @param PaymentCurrencyResolver $paymentCurrencyResolver
     */
    public function __construct(
        protected ScopeConfigInterface $scopeConfig,
        protected SignatureGenerator $signatureGenerator,
        protected CurrencyCodeResolver $currencyResolver,
        protected ObjectManagerInterface $objectManager,
        protected CustomerSession $customerSession,
        protected CustomerRepositoryInterface $customerRepository,
        protected OrderRepository $orderRepository,
        protected PaymentCurrencyResolver $paymentCurrencyResolver,
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->signatureGenerator = $signatureGenerator;
        $this->currencyResolver = $currencyResolver;
        $this->customerSession = $customerSession;
        $this->customerRepository = $customerRepository;
        $this->orderRepository = $orderRepository;
        $this->paymentCurrencyResolver = $paymentCurrencyResolver;
    }

    /**
     * @param string $order_id
     * @param int $total_amount
     * @param string $purchase_time
     *
     * @return SignatureResponseInterface
     * @throws LocalizedException
     */
    public function generateSignature(string $order_id, int $total_amount, string $purchase_time): SignatureResponseInterface
    {
        $merchantId = $this->scopeConfig->getValue('payment/upc_ecommconnect/merchant_id');
        $terminalId = $this->scopeConfig->getValue('payment/upc_ecommconnect/terminal_id');
        $action     = $this->scopeConfig->getValue('payment/upc_ecommconnect/action');
        $testMode   = $this->scopeConfig->isSetFlag('payment/upc_ecommconnect/test_mode');
        $delay      = $this->scopeConfig->isSetFlag('payment/upc_ecommconnect/delay');
        $locale     = $this->scopeConfig->getValue('payment/upc_ecommconnect/lang');

        $currency   = $this->currencyResolver->getNumericCode();
        $sessionId  = hash('sha256', $order_id . $purchase_time);

        $response = $this->objectManager->create(SignatureResponse::class);

        try {
            $order = $this->orderRepository->get($order_id);
            $customerIdFromOrder = $order->getCustomerId();
            $customerIdFromSession = $this->customerSession->getCustomerId();

            if (!$customerIdFromOrder || !$customerIdFromSession || $customerIdFromOrder != $customerIdFromSession) {
                throw new LocalizedException(
                    __('You are not allowed to use this order.')
                );
            }

            $customer = $this->customerRepository->getById($customerIdFromOrder);

            $tokenAttr = $customer->getCustomAttribute('upc_token');
            $expAttr = $customer->getCustomAttribute('upc_token_exp');
            if ($tokenAttr && $expAttr) {
                $token = $tokenAttr->getValue();
                $exp = $expAttr->getValue();
                $expMonth = (int)substr($exp, 0, 2);
                $expYear = (int)substr($exp, 2, 4);
                $currentMonth = (int)date('m');
                $currentYear = (int)date('Y');
                $isValid = ($expYear > $currentYear) || ($expYear === $currentYear && $expMonth >= $currentMonth);
                if ($isValid) {
                    $response->setUPCToken($token);
                }
            }
        } catch (\Exception $e) {
            // Токен не повертаємо в жодному разі
        }

        $order = $this->orderRepository->get($order_id);
        $orderCurrencyCode = $order->getOrderCurrencyCode();
        $orderTotal = $order->getGrandTotal();

        $resolvedCurrency = $this->paymentCurrencyResolver->resolve($orderCurrencyCode, $orderTotal);

        if (isset($resolvedCurrency['supported']) && $resolvedCurrency['supported'] === false) {
            throw new LocalizedException(__($resolvedCurrency['reason']));
        }

        $response->setAction($action.'/go/pay')
                 ->setMerchantId($merchantId)
                 ->setTerminalId($terminalId)
                 ->setCurrency((string)$resolvedCurrency['currency'])
                 ->setSession($sessionId)
                 ->setDelay($delay ? 1 : 0)
                 ->setAltCurrency((string)$resolvedCurrency['alt_currency'])
                 ->setAltTotalAmount((int)$resolvedCurrency['alt_total_amount'])
                 ->setLocale($locale);

        if ($testMode) {
            $response->setSignature('');
            return $response;
        }

        $params = [
            $merchantId,
            $terminalId,
            $purchase_time,
            $order_id,
            (string)$resolvedCurrency['currency'],
            $total_amount,
            $delay ? 1 : 0,
            (string)$resolvedCurrency['alt_currency'],
            (int)$resolvedCurrency['alt_total_amount']
        ];

        $signature = $this->signatureGenerator->generate($params);
        $response->setSignature($signature);

        return $response;
    }
}