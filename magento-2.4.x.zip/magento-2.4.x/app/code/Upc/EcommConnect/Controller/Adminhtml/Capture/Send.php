<?php

namespace Upc\EcommConnect\Controller\Adminhtml\Capture;

use Magento\Backend\App\Action;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\HTTP\Client\Curl;
use Magento\Sales\Model\Order;
use Psr\Log\LoggerInterface;
use Upc\EcommConnect\Service\CurrencyCodeResolver;

class Send extends Action
{
    protected OrderRepositoryInterface $orderRepository;
    protected JsonFactory $resultJsonFactory;
    protected Curl $curl;
    protected LoggerInterface $logger;
    protected ScopeConfigInterface $scopeConfig;
    protected CurrencyCodeResolver $currencyResolver;

    public function __construct(
        Action\Context $context,
        OrderRepositoryInterface $orderRepository,
        JsonFactory $resultJsonFactory,
        Curl $curl,
        LoggerInterface $logger,
        ScopeConfigInterface $scopeConfig,
        CurrencyCodeResolver $currencyResolver,
    ) {
        parent::__construct($context);
        $this->orderRepository = $orderRepository;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->curl = $curl;
        $this->logger = $logger;
        $this->scopeConfig = $scopeConfig;
        $this->currencyResolver = $currencyResolver;
    }

    public function execute()
    {
        $result = $this->resultJsonFactory->create();

        $orderId = $this->getRequest()->getParam('order_id');
        $totalAmount = (int)($this->getRequest()->getParam('totalAmount') * 100);

        if ($totalAmount < 1) {
            return $result->setData([
                'error' => true,
                'message' => __('Amount must be at least 1.')
            ]);
        }

        $url = $this->scopeConfig->getValue('payment/upc_ecommconnect/action');

        if (!$orderId) {
            return $result->setData([
                'error' => true,
                'message' => __('Order ID is missing')
            ]);
        }

        try {
            $order = $this->orderRepository->get($orderId);

            $orderTotal = (int)round($order->getGrandTotal() * 100);

            if ($totalAmount > $orderTotal) {
                return $result->setData([
                    'error' => true,
                    'message' => __('Amount cannot exceed order total: %1', $order->getGrandTotal())
                ]);
            }

            $postData = $this->getCaptureFormData($order, $totalAmount);

            $this->curl->setOption(CURLOPT_HTTPHEADER, ['Content-Type: application/x-www-form-urlencoded']);
            $this->curl->post($url.'/go/capture', http_build_query($postData));
            $body = $this->curl->getBody();

            if (preg_match('/<p>(.*?)<\/p>/s', $body, $matches)) {
                $lines = explode("\n", trim($matches[1]));
                $parsed = [];
                foreach ($lines as $line) {
                    if (str_contains($line, '=')) {
                        [$key, $value] = array_pad(explode('=', trim($line), 2), 2, '');
                        $parsed[trim($key)] = trim($value);
                    }
                }

                if (isset($parsed['TranCode']) && $parsed['TranCode'] === '000') {
                    $order->setState(Order::STATE_PROCESSING)
                          ->setStatus(Order::STATE_PROCESSING);
                    $order->addCommentToStatusHistory(__('Captured via UPC Gateway'));
                    $this->orderRepository->save($order);

                    return $result->setData([
                        'success' => true,
                        'message' => __('Capture success. Order moved to Processing'),
                    ]);
                } else {
                    return $result->setData([
                        'error' => true,
                        'message' => __('Capture failed: %1', json_encode($parsed)),
                        'parsed' => $parsed,
                        'postData' => $postData,
                    ]);
                }
            }

            return $result->setData(['error' => true, 'message' => __('Invalid response from UPC')]);

        } catch (\Exception $e) {
            $this->logger->error($e->getMessage());
            return $result->setData(['error' => true, 'message' => $e->getMessage()]);
        }
    }

    public function getCaptureFormData(OrderInterface $order, int $totalAmount): array
    {
        $payment = $order->getPayment();

        return [
            'MerchantID' => $this->scopeConfig->getValue('payment/upc_ecommconnect/merchant_id'),
            'TerminalID' => $this->scopeConfig->getValue('payment/upc_ecommconnect/terminal_id'),
            'OrderID' => $order->getId(),
            'Currency'    => $this->currencyResolver->getNumericCode(),
            'TotalAmount' => (int)($order->getGrandTotal() * 100),
            'PurchaseTime' => $payment->getAdditionalInformation('upc_purchase_time'),
            'ApprovalCode' => $payment->getAdditionalInformation('upc_approval_code'),
            'RRN'          => $payment->getAdditionalInformation('upc_rrn'),
            'PostauthorizationAmount' => $totalAmount,
            'Signature'     => $payment->getAdditionalInformation('upc_signature'),
        ];
    }
}