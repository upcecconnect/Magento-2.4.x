<?php
namespace Upc\EcommConnect\Gateway\Command;

use Magento\Payment\Gateway\CommandInterface;
use Magento\Sales\Model\Order;

class AuthorizeCommand implements CommandInterface
{
    public function execute(array $commandSubject)
    {

        if (!isset($commandSubject['payment'])) {
            return null;
        }

        $payment = $commandSubject['payment']->getPayment();
        $order = $payment->getOrder();

        $payment->setIsTransactionPending(true);
        $payment->setIsTransactionClosed(false);

        $order->setState(Order::STATE_PENDING_PAYMENT)
              ->setStatus(Order::STATE_PENDING_PAYMENT);

        $order->addCommentToStatusHistory(
            __('Очікуємо підтвердження оплати через UPC e-Commerce Gateway'),
            false,
            false
        );

        return null;
    }
}
