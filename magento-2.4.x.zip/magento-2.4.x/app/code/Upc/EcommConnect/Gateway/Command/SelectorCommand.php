<?php
namespace Upc\EcommConnect\Gateway\Command;

use Magento\Payment\Gateway\CommandInterface;
use Magento\Payment\Gateway\ConfigInterface;

class SelectorCommand implements CommandInterface
{
    private ConfigInterface $config;
    private CommandInterface $authorizeCommand;
    private CommandInterface $preauthorizeCommand;

    public function __construct(
        ConfigInterface $config,
        CommandInterface $authorizeCommand,
        CommandInterface $preauthorizeCommand
    ) {
        $this->config = $config;
        $this->authorizeCommand = $authorizeCommand;
        $this->preauthorizeCommand = $preauthorizeCommand;
    }

    public function execute(array $commandSubject)
    {
        $delay = (bool) $this->config->getValue('delay');
        if ($delay) {
            return $this->preauthorizeCommand->execute($commandSubject);
        } else {
            return $this->authorizeCommand->execute($commandSubject);
        }
    }
}