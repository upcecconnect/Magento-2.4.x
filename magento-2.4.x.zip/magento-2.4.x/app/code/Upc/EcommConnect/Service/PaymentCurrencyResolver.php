<?php

namespace Upc\EcommConnect\Service;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Directory\Model\CurrencyFactory;

class PaymentCurrencyResolver
{
    public function __construct(
        protected ScopeConfigInterface $scopeConfig,
        protected StoreManagerInterface $storeManager,
        protected CurrencyFactory $currencyFactory
    ) {}

    public function resolve(string $orderCurrencyCode, float $orderTotal): array
    {
        $contractCurrency = $this->scopeConfig->getValue('payment/upc_ecommconnect/contract_currency'); // numeric
        $altCurrency = $this->scopeConfig->getValue('payment/upc_ecommconnect/alt_currency'); // numeric
        $altCurrency = (int)$altCurrency;

        $available = [
            'USD' => 840,
            'EUR' => 978,
            'UAH' => 980,
            'BAM' => 977,
            'HUF' => 348,
            'BGN' => 975,
            'RSD' => 941,
            'ALL' => 8,
        ];

        $baseCurrency = $this->storeManager->getStore()->getBaseCurrencyCode();
        $orderCurrencyNumeric = $available[$orderCurrencyCode] ?? null;

        $contractCurrency = (int)$contractCurrency;
        $totalAmount = round($orderTotal * 100);
        $altTotalAmount = $totalAmount;

        if ($orderCurrencyNumeric === $contractCurrency) {
            $altCurrency = $contractCurrency;
        } elseif ($altCurrency === 978 || $altCurrency === 840) {
            $baseRate = $this->currencyFactory->create()->load($orderCurrencyCode)->getRate('USD');
            if ($altCurrency === 978) {
                $baseRate = $this->currencyFactory->create()->load($orderCurrencyCode)->getRate('EUR');
            }
            if ($baseRate) {
                $altTotalAmount = round(($orderTotal / $baseRate) * 100);
            }
        }

        if (!$orderCurrencyNumeric || (!in_array($altCurrency, [840, 978], true) && $orderCurrencyNumeric !== $contractCurrency)) {
            return [
                'supported' => false,
                'currency' => $contractCurrency,
                'reason' => __('Selected currency is not supported for this payment method.')
            ];
        }

        return [
            'currency'         => $contractCurrency,
            'total_amount'     => $totalAmount,
            'alt_currency'     => $altCurrency,
            'alt_total_amount' => $altTotalAmount,
        ];
    }
}
