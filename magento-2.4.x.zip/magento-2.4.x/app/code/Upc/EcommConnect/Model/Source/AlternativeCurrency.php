<?php

declare(strict_types=1);

namespace Upc\EcommConnect\Model\Source;

class AlternativeCurrency
{
    public function toOptionArray(): array
    {
        return [
            ['value' => '840', 'label' => 'USD'],
            ['value' => '978', 'label' => 'EUR'],
        ];
    }
}
